u.on(window, 'load', function() {
	document.getElementById('combo2')['u.Combo'].setComboData([{value:'01',name:'男'},{value:'02',name:'女'}]);
})